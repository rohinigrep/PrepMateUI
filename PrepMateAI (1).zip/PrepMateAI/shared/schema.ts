import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Resumes table
export const resumes = pgTable("resumes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  fileName: text("file_name").notNull(),
  fileUrl: text("file_url").notNull(),
  extractedText: text("extracted_text"),
  skills: text("skills").array(),
  experience: text("experience").array(),
  education: text("education").array(),
  uploadedAt: timestamp("uploaded_at").defaultNow().notNull(),
});

// Job Descriptions table
export const jobDescriptions = pgTable("job_descriptions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description").notNull(),
  requiredSkills: text("required_skills").array(),
  difficultyLevel: text("difficulty_level").notNull(), // 'beginner', 'intermediate', 'advanced'
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Interview Sessions table
export const interviewSessions = pgTable("interview_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  resumeId: varchar("resume_id").references(() => resumes.id),
  jobDescriptionId: varchar("job_description_id").references(() => jobDescriptions.id),
  status: text("status").notNull().default("in_progress"), // 'in_progress', 'completed', 'abandoned'
  difficultyLevel: text("difficulty_level").notNull(),
  startedAt: timestamp("started_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
  overallScore: integer("overall_score"),
  verbalScore: integer("verbal_score"),
  nonVerbalScore: integer("non_verbal_score"),
  resumeMatchScore: integer("resume_match_score"),
});

// Questions table
export const questions = pgTable("questions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").notNull().references(() => interviewSessions.id, { onDelete: "cascade" }),
  questionText: text("question_text").notNull(),
  questionNumber: integer("question_number").notNull(),
  category: text("category").notNull(), // 'technical', 'behavioral', 'situational'
  askedAt: timestamp("asked_at").defaultNow().notNull(),
});

// Answers table
export const answers = pgTable("answers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  questionId: varchar("question_id").notNull().references(() => questions.id, { onDelete: "cascade" }),
  sessionId: varchar("session_id").notNull().references(() => interviewSessions.id, { onDelete: "cascade" }),
  transcribedText: text("transcribed_text").notNull(),
  audioUrl: text("audio_url"),
  score: integer("score"),
  strengths: text("strengths").array(),
  improvements: text("improvements").array(),
  answeredAt: timestamp("answered_at").defaultNow().notNull(),
});

// Non-verbal Analysis table
export const nonVerbalAnalysis = pgTable("non_verbal_analysis", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").notNull().references(() => interviewSessions.id, { onDelete: "cascade" }),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  facialExpression: text("facial_expression"), // 'happy', 'neutral', 'nervous', 'confident'
  eyeContact: integer("eye_contact"), // 0-100 score
  posture: text("posture"), // 'good', 'slouching', 'fidgeting'
  confidenceLevel: integer("confidence_level"), // 0-100 score
  emotionData: jsonb("emotion_data"), // detailed emotion breakdown from DeepFace
});

// Feedback table
export const feedback = pgTable("feedback", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").notNull().references(() => interviewSessions.id, { onDelete: "cascade" }),
  verbalFeedback: text("verbal_feedback").notNull(),
  nonVerbalFeedback: text("non_verbal_feedback").notNull(),
  overallFeedback: text("overall_feedback").notNull(),
  recommendations: text("recommendations").array(),
  strengths: text("strengths").array(),
  areasForImprovement: text("areas_for_improvement").array(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Zod Schemas for validation
export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  password: true,
  name: true,
}).extend({
  email: z.string().email("Invalid email address"),
  password: z.string().min(8, "Password must be at least 8 characters"),
  name: z.string().min(2, "Name must be at least 2 characters"),
});

export const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(1, "Password is required"),
});

export const insertResumeSchema = createInsertSchema(resumes).pick({
  fileName: true,
  fileUrl: true,
  extractedText: true,
  skills: true,
  experience: true,
  education: true,
});

export const insertJobDescriptionSchema = createInsertSchema(jobDescriptions).pick({
  title: true,
  description: true,
  requiredSkills: true,
  difficultyLevel: true,
}).extend({
  title: z.string().min(3, "Job title is required"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  requiredSkills: z.array(z.string()).optional(),
  difficultyLevel: z.enum(["beginner", "intermediate", "advanced"]),
});

export const insertInterviewSessionSchema = createInsertSchema(interviewSessions).pick({
  resumeId: true,
  jobDescriptionId: true,
  difficultyLevel: true,
}).extend({
  difficultyLevel: z.enum(["beginner", "intermediate", "advanced"]),
});

export const insertQuestionSchema = createInsertSchema(questions).pick({
  questionText: true,
  questionNumber: true,
  category: true,
}).extend({
  category: z.enum(["technical", "behavioral", "situational"]),
});

export const insertAnswerSchema = createInsertSchema(answers).pick({
  transcribedText: true,
  audioUrl: true,
});

export const insertNonVerbalAnalysisSchema = createInsertSchema(nonVerbalAnalysis).pick({
  facialExpression: true,
  eyeContact: true,
  posture: true,
  confidenceLevel: true,
  emotionData: true,
});

export const insertFeedbackSchema = createInsertSchema(feedback).pick({
  verbalFeedback: true,
  nonVerbalFeedback: true,
  overallFeedback: true,
  recommendations: true,
  strengths: true,
  areasForImprovement: true,
});

// TypeScript types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginUser = z.infer<typeof loginSchema>;

export type Resume = typeof resumes.$inferSelect;
export type InsertResume = z.infer<typeof insertResumeSchema>;

export type JobDescription = typeof jobDescriptions.$inferSelect;
export type InsertJobDescription = z.infer<typeof insertJobDescriptionSchema>;

export type InterviewSession = typeof interviewSessions.$inferSelect;
export type InsertInterviewSession = z.infer<typeof insertInterviewSessionSchema>;

export type Question = typeof questions.$inferSelect;
export type InsertQuestion = z.infer<typeof insertQuestionSchema>;

export type Answer = typeof answers.$inferSelect;
export type InsertAnswer = z.infer<typeof insertAnswerSchema>;

export type NonVerbalAnalysis = typeof nonVerbalAnalysis.$inferSelect;
export type InsertNonVerbalAnalysis = z.infer<typeof insertNonVerbalAnalysisSchema>;

export type Feedback = typeof feedback.$inferSelect;
export type InsertFeedback = z.infer<typeof insertFeedbackSchema>;
