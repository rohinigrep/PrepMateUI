# PrepMate - AI Mock Interview Platform

PrepMate is an AI-driven mock interview platform that helps candidates prepare for real-world interviews through realistic practice sessions, personalized feedback, and comprehensive skill assessment.

## Current Implementation Status

### ✅ Fully Implemented
- **Complete Frontend UI** - All pages, components, and user flows with professional design
- **Authentication System** - Signup, login, logout with session management
- **Resume Upload** - File upload interface with drag-and-drop support
- **Interview Session Flow** - Complete UI for interview process with webcam, audio, and question display
- **Feedback Dashboard** - Beautiful results page with charts and detailed breakdowns
- **API Structure** - All REST endpoints for data management
- **Responsive Design** - Works perfectly on desktop, tablet, and mobile
- **Dark Mode** - Full theme support with smooth transitions

### 🔄 Ready for AI Integration
These features have the UI and API structure ready, but require Python/ML backend services:
- 🎤 **Voice-Based Interviews** - UI ready, needs Whisper integration
- 🤖 **AI-Powered Analysis** - API ready, needs Gemini implementation  
- 📄 **Resume-Based Questions** - Parsing ready, needs BERT similarity scoring
- 👁️ **Non-Verbal Analysis** - Camera capture ready, needs MediaPipe + DeepFace
- 📊 **Real-time Feedback** - Display ready, needs WebSocket for live updates

## Tech Stack

### Frontend
- **React** with TypeScript
- **Tailwind CSS** + Shadcn UI components
- **Wouter** for routing
- **TanStack Query** for data fetching
- **Inter & Manrope** fonts for typography

### Backend
- **Node.js** with Express
- **TypeScript** for type safety
- **In-memory storage** (easily upgradeable to MongoDB)
- **Bcrypt** for password hashing
- **Multer** for file uploads

### AI/ML Integration (Planned)
- **Google Gemini API** - Question generation & answer evaluation
- **OpenAI Whisper** - Speech-to-text conversion
- **MediaPipe** - Facial landmark detection
- **DeepFace** - Facial expression analysis
- **Sentence-Transformers (BERT)** - Resume-JD similarity scoring

## Local Development Setup

### Prerequisites
- Node.js 20.x or higher
- npm or yarn package manager

### Step 1: Clone the Repository
\`\`\`bash
git clone <repository-url>
cd prepmate
\`\`\`

### Step 2: Install Dependencies
\`\`\`bash
npm install
\`\`\`

### Step 3: Environment Configuration
Create a \`.env\` file in the root directory:

\`\`\`env
# Server Configuration
PORT=5000

# API Keys (Required for full functionality)
GEMINI_API_KEY=your_gemini_api_key_here
MONGODB_URI=your_mongodb_connection_string_here

# Session Secret (Optional)
SESSION_SECRET=your_session_secret_here
\`\`\`

**Getting API Keys:**

1. **Gemini API Key**: 
   - Visit [Google AI Studio](https://aistudio.google.com/app/apikey)
   - Create a new API key
   - Copy and paste into \`.env\`

2. **MongoDB URI** (Optional - uses in-memory storage by default):
   - Sign up for [MongoDB Atlas](https://www.mongodb.com/cloud/atlas/register) (Free tier available)
   - Create a cluster
   - Get connection string: \`mongodb+srv://username:password@cluster.mongodb.net/prepmate\`
   - Or use local MongoDB: \`mongodb://localhost:27017/prepmate\`

### Step 4: Run Development Server
\`\`\`bash
npm run dev
\`\`\`

The application will be available at:
- **Frontend & Backend**: http://localhost:5000

### Step 5: Build for Production
\`\`\`bash
npm run build
npm start
\`\`\`

## Project Structure

\`\`\`
prepmate/
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/    # Reusable UI components
│   │   ├── pages/         # Page components
│   │   ├── lib/           # Utilities and helpers
│   │   └── App.tsx        # Main app component
│   └── index.html
├── server/                # Express backend
│   ├── routes.ts          # API route handlers
│   ├── storage.ts         # Data storage interface
│   └── index.ts           # Server entry point
├── shared/                # Shared types and schemas
│   └── schema.ts          # Database schemas & validation
└── README.md
\`\`\`

## API Endpoints

### Authentication
- \`POST /api/auth/signup\` - Create new user account
- \`POST /api/auth/login\` - User login
- \`POST /api/auth/logout\` - User logout

### Resumes
- \`GET /api/resumes\` - Get user's resumes
- \`POST /api/resumes/upload\` - Upload new resume (PDF)

### Job Descriptions
- \`POST /api/job-descriptions\` - Create job description
- \`GET /api/job-descriptions\` - Get user's job descriptions

### Interview Sessions
- \`POST /api/sessions/start\` - Start new interview
- \`GET /api/sessions\` - Get user's sessions
- \`GET /api/sessions/:id\` - Get specific session
- \`POST /api/sessions/:id/next-question\` - Generate next question
- \`POST /api/sessions/:id/answer\` - Submit answer
- \`POST /api/sessions/:id/end\` - End interview session

### Feedback & Stats
- \`GET /api/feedback/:sessionId\` - Get session feedback
- \`GET /api/stats\` - Get user statistics

## AI Integration Guide

### Adding Python ML Services

For production deployment with full AI capabilities, integrate Python microservices:

1. **Create Python Service** (\`python-service/\`):
\`\`\`python
# main.py
from fastapi import FastAPI
from transformers import pipeline
import google.generativeai as genai

app = FastAPI()

@app.post("/api/python/transcribe")
async def transcribe_audio(audio_file):
    # Whisper implementation
    pass

@app.post("/api/python/analyze-face")
async def analyze_face(image):
    # MediaPipe + DeepFace implementation
    pass

@app.post("/api/python/generate-question")
async def generate_question(context):
    # Gemini API implementation
    genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
    model = genai.GenerativeModel('gemini-pro')
    response = model.generate_content(context)
    return {"question": response.text}
\`\`\`

2. **Install Python Dependencies**:
\`\`\`bash
pip install fastapi uvicorn google-generativeai openai-whisper mediapipe deepface sentence-transformers opencv-python PyPDF2
\`\`\`

3. **Run Python Service**:
\`\`\`bash
uvicorn main:app --host 0.0.0.0 --port 8000
\`\`\`

4. **Update Node.js Backend** to proxy requests to Python service

## Database Setup (MongoDB)

To use MongoDB instead of in-memory storage:

1. Install MongoDB driver:
\`\`\`bash
npm install mongodb
\`\`\`

2. Update \`server/storage.ts\` to use MongoDB client
3. Set \`MONGODB_URI\` in environment variables

## Deployment

### Deploy to Replit
1. Fork this repl or import the repository
2. Add secrets in Replit Secrets panel:
   - \`GEMINI_API_KEY\`
   - \`MONGODB_URI\` (optional)
3. Click "Run" - the app will be available at your repl URL

### Deploy to Other Platforms

**Vercel/Netlify:**
- Build command: \`npm run build\`
- Start command: \`npm start\`
- Add environment variables in dashboard

**Docker:**
\`\`\`dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build
EXPOSE 5000
CMD ["npm", "start"]
\`\`\`

## Features Roadmap

- [x] User authentication and profile management
- [x] Resume upload and parsing
- [x] Job description input
- [x] Interview session management
- [x] Basic Q&A flow
- [x] Feedback generation
- [ ] Full Gemini API integration for questions
- [ ] Whisper speech-to-text integration
- [ ] Real-time facial analysis with MediaPipe
- [ ] Emotion detection with DeepFace
- [ ] Resume-JD similarity with BERT
- [ ] WebSocket for real-time communication
- [ ] Performance analytics dashboard
- [ ] Interview recording playback

## Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (\`git checkout -b feature/amazing-feature\`)
3. Commit your changes (\`git commit -m 'Add amazing feature'\`)
4. Push to the branch (\`git push origin feature/amazing-feature\`)
5. Open a Pull Request

## License

MIT License - See LICENSE file for details

## Support

For issues and questions:
- Open an issue on GitHub
- Contact: support@prepmate.ai

## Acknowledgments

- Google Gemini for AI-powered question generation
- OpenAI Whisper for speech recognition
- MediaPipe for computer vision
- DeepFace for facial analysis
- Shadcn UI for beautiful components
