# PrepMate AI Mock Interview Platform - Design Guidelines

## Design Approach

**Selected Approach:** Hybrid Design System (Material Design foundation + Linear/Notion-inspired aesthetics)
- **Rationale:** PrepMate is a professional productivity tool requiring clarity and efficiency, but also needs to feel modern and approachable to reduce interview anxiety
- **Key Principles:** Trust through professionalism, clarity over decoration, progressive disclosure of complexity, confidence-building visual language

---

## Core Design Elements

### A. Color Palette

**Dark Mode (Primary):**
- Background Base: 222 15% 8%
- Surface Elevated: 222 15% 12%
- Surface Interactive: 222 12% 16%
- Primary Brand: 220 90% 56% (confident blue)
- Success/Positive: 142 76% 45%
- Warning/Attention: 38 92% 50%
- Error/Critical: 0 84% 60%
- Text Primary: 0 0% 98%
- Text Secondary: 0 0% 70%

**Light Mode:**
- Background Base: 0 0% 100%
- Surface Elevated: 220 20% 98%
- Surface Interactive: 220 15% 95%
- Primary Brand: 220 90% 56%
- Text Primary: 222 15% 12%
- Text Secondary: 222 10% 40%

### B. Typography

**Font Stack:**
- Primary: 'Inter' (Google Fonts) - UI, body text, forms
- Accent: 'Manrope' (Google Fonts) - headings, emphasis

**Hierarchy:**
- Hero Headlines: 48px/56px, font-weight 700
- Section Headers: 32px/40px, font-weight 600  
- Subsection Headers: 24px/32px, font-weight 600
- Body Large: 18px/28px, font-weight 400
- Body Default: 16px/24px, font-weight 400
- Body Small: 14px/20px, font-weight 400
- Captions: 12px/16px, font-weight 500

### C. Layout System

**Spacing Scale:** Consistent Tailwind units: 4, 8, 12, 16, 24, 32, 48
- Component padding: p-4, p-6, p-8
- Section spacing: py-16 md:py-24 lg:py-32
- Grid gaps: gap-4, gap-6, gap-8
- Container max-width: max-w-7xl with px-4 md:px-8

---

## Component Library

### Navigation
- **Top Navigation:** Fixed header with logo left, main nav center, user profile/CTA right. Background: surface elevated with subtle border-b. Height: h-16
- **Dashboard Sidebar:** Collapsible left sidebar (w-64) with icon+text navigation, current state highlighted with primary color and elevated background

### Cards & Surfaces
- **Interview Session Card:** Elevated surface with subtle shadow, rounded-xl, p-6, includes status indicator, role badge, timestamp, and action button
- **Feedback Card:** Glass-morphism effect for analysis results, blur backdrop, border with primary tint
- **Stats Dashboard:** Grid of metric cards (grid-cols-1 md:grid-cols-3 lg:grid-cols-4), each with large number, label, and trend indicator

### Forms & Inputs
- **Input Fields:** Consistent height h-12, rounded-lg, dark mode with bg-surface-interactive, border-2 with focus:border-primary transition
- **File Upload:** Drag-and-drop zone with dashed border, icon, helper text. Active state shows primary border and slight scale effect
- **Select Dropdowns:** Custom styled with chevron icon, matches input height, smooth dropdown reveal

### Interview Interface
- **Video Feed Container:** Aspect ratio 16:9 or 4:3, rounded-lg overflow-hidden, positioned top-right during interview (absolute positioning)
- **Question Display:** Large central card with generous padding (p-8), question text prominent (text-2xl), timer indicator, speaking status badge
- **Control Panel:** Bottom fixed toolbar (h-20) with microphone, camera, end session controls. Icon buttons with tooltips

### Data Visualization
- **Performance Metrics:** Radial progress indicators for scores, horizontal bar charts for skill breakdown, timeline view for interview history
- **Feedback Sections:** Accordion-style expandable panels, each with icon, title, score, and detailed breakdown

### Buttons & CTAs
- **Primary:** bg-primary, text-white, px-6 py-3, rounded-lg, font-medium, hover:bg-primary/90
- **Secondary:** border-2 border-primary, text-primary, same padding/styling
- **Ghost:** text-primary, hover:bg-surface-interactive
- **Destructive:** bg-error, text-white (for end session, delete)

### Overlays & Modals
- **Modal:** Centered, max-w-2xl, rounded-2xl, p-8, backdrop blur-md with dark overlay
- **Toast Notifications:** Top-right position, slide-in animation, auto-dismiss, color-coded by type
- **Loading States:** Skeleton screens for data-heavy views, spinner with brand color for actions

---

## Page-Specific Guidelines

### Landing Page
**Hero Section (80vh):**
- Split layout: Left 60% - headline, subheadline, dual CTA buttons (Start Practice + Watch Demo), trust indicators. Right 40% - animated mockup/illustration of interview interface
- Background: Subtle gradient from base to slightly lighter surface
- No floating elements - grounded design with contained max-width

**Features Section (multi-column):**
- 3-column grid (grid-cols-1 md:grid-cols-3) showcasing core features
- Each card: Icon (from Heroicons), title, description, "Learn more" link
- Staggered reveal on scroll (optional subtle fade-in)

**How It Works:**
- Horizontal stepper/timeline showing 4 steps: Upload Resume → Start Interview → AI Analysis → Get Feedback
- Visual connectors between steps
- Each step with icon, number badge, title, brief description

**Social Proof:**
- Stats bar: Grid of 4 metrics (Users, Sessions Completed, Average Score Improvement, Companies)
- Testimonial carousel: 3 visible cards (grid-cols-1 md:grid-cols-3), avatar, quote, name, role

**CTA Section:**
- Centered, bg-primary/10, rounded-2xl, p-12
- Headline, supporting text, primary button, secondary link

### Dashboard
**Top Metrics Row:** 4 stat cards showing recent performance, sessions completed, average score, improvement trend

**Main Content Area (2-column lg:grid-cols-3 gap-6):**
- Left Column (col-span-2): Interview history table/list, quick actions, recent feedback
- Right Column: Upcoming sessions, recommended practice areas, performance chart

### Interview Session Page
**Full-screen Layout:**
- Top: Timer, role indicator, question number
- Center: Large question card (animated entrance)
- Bottom-right (overlay): User video feed, expression indicators
- Bottom: Control panel with mic/camera toggle, end session

### Feedback/Results Page
**Header:** Overall score (large radial chart), session metadata

**Tabbed Content:**
- Tabs: Verbal Analysis | Non-Verbal Analysis | Resume Match | Recommendations
- Each tab: Detailed breakdown with scores, charts, text analysis, actionable tips

---

## Images

**Hero Section Image:**
- Placement: Right side of hero (40% width)
- Description: Clean UI mockup/3D illustration showing the interview interface with AI analysis overlay, semi-transparent with depth
- Style: Modern, tech-forward, professional but approachable

**Feature Cards:**
- Each feature card can include a subtle icon (Heroicons) rather than full images
- Consider small illustrative graphics for complex features (CV analysis visualization)

**Testimonials:**
- User avatars: Circular, 48px diameter
- Consider diverse representation

**Dashboard:**
- Optional: Empty state illustrations when no data (friendly, encouraging tone)

---

## Animation & Interaction

**Micro-interactions (Minimal):**
- Button hover: Subtle scale (scale-105) and brightness change
- Card hover: Slight elevation increase (shadow-lg)
- Input focus: Border color transition
- Page transitions: Fade-in content, no complex animations

**Interview Session:**
- Real-time visual feedback: Pulse effect on mic when speaking
- Question transitions: Fade + slight slide
- Analysis indicators: Subtle progress fills

**Avoid:** Excessive parallax, distracting background animations, auto-playing videos

---

## Accessibility & Responsive

- Maintain WCAG AA contrast ratios (4.5:1 text, 3:1 UI)
- All interactive elements minimum 44px touch target
- Keyboard navigation with visible focus indicators
- Screen reader labels for all icons and interactive elements
- Mobile: Single column layouts, bottom navigation, collapsible sections
- Tablet: Adaptive 2-column where appropriate
- Desktop: Full multi-column layouts with sidebar