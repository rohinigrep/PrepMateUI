import { 
  type User, type InsertUser,
  type Resume, type InsertResume,
  type JobDescription, type InsertJobDescription,
  type InterviewSession, type InsertInterviewSession,
  type Question, type InsertQuestion,
  type Answer, type InsertAnswer,
  type NonVerbalAnalysis, type InsertNonVerbalAnalysis,
  type Feedback, type InsertFeedback
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Resume methods
  getResume(id: string): Promise<Resume | undefined>;
  getUserResumes(userId: string): Promise<Resume[]>;
  createResume(resume: InsertResume & { userId: string }): Promise<Resume>;

  // Job Description methods
  getJobDescription(id: string): Promise<JobDescription | undefined>;
  getUserJobDescriptions(userId: string): Promise<JobDescription[]>;
  createJobDescription(jd: InsertJobDescription & { userId: string }): Promise<JobDescription>;

  // Interview Session methods
  getSession(id: string): Promise<InterviewSession | undefined>;
  getUserSessions(userId: string): Promise<InterviewSession[]>;
  createSession(session: InsertInterviewSession & { userId: string }): Promise<InterviewSession>;
  updateSession(id: string, updates: Partial<InterviewSession>): Promise<InterviewSession>;

  // Question methods
  getQuestion(id: string): Promise<Question | undefined>;
  getSessionQuestions(sessionId: string): Promise<Question[]>;
  createQuestion(question: InsertQuestion & { sessionId: string }): Promise<Question>;

  // Answer methods
  getAnswer(id: string): Promise<Answer | undefined>;
  getSessionAnswers(sessionId: string): Promise<Answer[]>;
  createAnswer(answer: InsertAnswer & { questionId: string; sessionId: string }): Promise<Answer>;

  // Non-verbal Analysis methods
  getSessionNonVerbalAnalysis(sessionId: string): Promise<NonVerbalAnalysis[]>;
  createNonVerbalAnalysis(analysis: InsertNonVerbalAnalysis & { sessionId: string }): Promise<NonVerbalAnalysis>;

  // Feedback methods
  getSessionFeedback(sessionId: string): Promise<Feedback | undefined>;
  createFeedback(feedback: InsertFeedback & { sessionId: string }): Promise<Feedback>;

  // Stats methods
  getUserStats(userId: string): Promise<any>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private resumes: Map<string, Resume>;
  private jobDescriptions: Map<string, JobDescription>;
  private sessions: Map<string, InterviewSession>;
  private questions: Map<string, Question>;
  private answers: Map<string, Answer>;
  private nonVerbalAnalysis: Map<string, NonVerbalAnalysis>;
  private feedbacks: Map<string, Feedback>;

  constructor() {
    this.users = new Map();
    this.resumes = new Map();
    this.jobDescriptions = new Map();
    this.sessions = new Map();
    this.questions = new Map();
    this.answers = new Map();
    this.nonVerbalAnalysis = new Map();
    this.feedbacks = new Map();
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  // Resume methods
  async getResume(id: string): Promise<Resume | undefined> {
    return this.resumes.get(id);
  }

  async getUserResumes(userId: string): Promise<Resume[]> {
    return Array.from(this.resumes.values()).filter(
      (resume) => resume.userId === userId
    );
  }

  async createResume(resume: InsertResume & { userId: string }): Promise<Resume> {
    const id = randomUUID();
    const newResume: Resume = {
      ...resume,
      id,
      uploadedAt: new Date()
    };
    this.resumes.set(id, newResume);
    return newResume;
  }

  // Job Description methods
  async getJobDescription(id: string): Promise<JobDescription | undefined> {
    return this.jobDescriptions.get(id);
  }

  async getUserJobDescriptions(userId: string): Promise<JobDescription[]> {
    return Array.from(this.jobDescriptions.values()).filter(
      (jd) => jd.userId === userId
    );
  }

  async createJobDescription(jd: InsertJobDescription & { userId: string }): Promise<JobDescription> {
    const id = randomUUID();
    const newJd: JobDescription = {
      ...jd,
      id,
      createdAt: new Date()
    };
    this.jobDescriptions.set(id, newJd);
    return newJd;
  }

  // Interview Session methods
  async getSession(id: string): Promise<InterviewSession | undefined> {
    return this.sessions.get(id);
  }

  async getUserSessions(userId: string): Promise<InterviewSession[]> {
    return Array.from(this.sessions.values())
      .filter((session) => session.userId === userId)
      .sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime());
  }

  async createSession(session: InsertInterviewSession & { userId: string }): Promise<InterviewSession> {
    const id = randomUUID();
    const newSession: InterviewSession = {
      ...session,
      id,
      status: 'in_progress',
      startedAt: new Date(),
      completedAt: null,
      overallScore: null,
      verbalScore: null,
      nonVerbalScore: null,
      resumeMatchScore: null
    };
    this.sessions.set(id, newSession);
    return newSession;
  }

  async updateSession(id: string, updates: Partial<InterviewSession>): Promise<InterviewSession> {
    const session = this.sessions.get(id);
    if (!session) {
      throw new Error("Session not found");
    }
    const updated = { ...session, ...updates };
    this.sessions.set(id, updated);
    return updated;
  }

  // Question methods
  async getQuestion(id: string): Promise<Question | undefined> {
    return this.questions.get(id);
  }

  async getSessionQuestions(sessionId: string): Promise<Question[]> {
    return Array.from(this.questions.values())
      .filter((question) => question.sessionId === sessionId)
      .sort((a, b) => a.questionNumber - b.questionNumber);
  }

  async createQuestion(question: InsertQuestion & { sessionId: string }): Promise<Question> {
    const id = randomUUID();
    const newQuestion: Question = {
      ...question,
      id,
      askedAt: new Date()
    };
    this.questions.set(id, newQuestion);
    return newQuestion;
  }

  // Answer methods
  async getAnswer(id: string): Promise<Answer | undefined> {
    return this.answers.get(id);
  }

  async getSessionAnswers(sessionId: string): Promise<Answer[]> {
    return Array.from(this.answers.values()).filter(
      (answer) => answer.sessionId === sessionId
    );
  }

  async createAnswer(answer: InsertAnswer & { questionId: string; sessionId: string }): Promise<Answer> {
    const id = randomUUID();
    const newAnswer: Answer = {
      ...answer,
      id,
      score: null,
      strengths: null,
      improvements: null,
      answeredAt: new Date()
    };
    this.answers.set(id, newAnswer);
    return newAnswer;
  }

  // Non-verbal Analysis methods
  async getSessionNonVerbalAnalysis(sessionId: string): Promise<NonVerbalAnalysis[]> {
    return Array.from(this.nonVerbalAnalysis.values()).filter(
      (analysis) => analysis.sessionId === sessionId
    );
  }

  async createNonVerbalAnalysis(analysis: InsertNonVerbalAnalysis & { sessionId: string }): Promise<NonVerbalAnalysis> {
    const id = randomUUID();
    const newAnalysis: NonVerbalAnalysis = {
      ...analysis,
      id,
      timestamp: new Date()
    };
    this.nonVerbalAnalysis.set(id, newAnalysis);
    return newAnalysis;
  }

  // Feedback methods
  async getSessionFeedback(sessionId: string): Promise<Feedback | undefined> {
    return Array.from(this.feedbacks.values()).find(
      (feedback) => feedback.sessionId === sessionId
    );
  }

  async createFeedback(feedback: InsertFeedback & { sessionId: string }): Promise<Feedback> {
    const id = randomUUID();
    const newFeedback: Feedback = {
      ...feedback,
      id,
      createdAt: new Date()
    };
    this.feedbacks.set(id, newFeedback);
    return newFeedback;
  }

  // Stats methods
  async getUserStats(userId: string): Promise<any> {
    const sessions = await this.getUserSessions(userId);
    const completedSessions = sessions.filter(s => s.status === 'completed');
    
    const avgScore = completedSessions.length > 0
      ? Math.round(completedSessions.reduce((sum, s) => sum + (s.overallScore || 0), 0) / completedSessions.length)
      : 0;

    const avgVerbal = completedSessions.length > 0
      ? Math.round(completedSessions.reduce((sum, s) => sum + (s.verbalScore || 0), 0) / completedSessions.length)
      : 0;

    const avgNonVerbal = completedSessions.length > 0
      ? Math.round(completedSessions.reduce((sum, s) => sum + (s.nonVerbalScore || 0), 0) / completedSessions.length)
      : 0;

    const avgResumeMatch = completedSessions.length > 0
      ? Math.round(completedSessions.reduce((sum, s) => sum + (s.resumeMatchScore || 0), 0) / completedSessions.length)
      : 0;

    const resumes = await this.getUserResumes(userId);

    return {
      totalSessions: sessions.length,
      avgScore,
      verbalScore: avgVerbal,
      nonVerbalScore: avgNonVerbal,
      resumeMatchScore: avgResumeMatch,
      resumesUploaded: resumes.length,
      improvement: avgScore > 0 ? Math.min(avgScore - 50, 30) : 0
    };
  }
}

export const storage = new MemStorage();
