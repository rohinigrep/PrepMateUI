import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import bcrypt from "bcryptjs";
import { 
  insertUserSchema, 
  loginSchema,
  insertResumeSchema,
  insertJobDescriptionSchema,
  insertInterviewSessionSchema,
  insertAnswerSchema,
  type User 
} from "@shared/schema";
import multer from "multer";
import path from "path";

// Simple session management (in production, use express-session with a proper store)
const sessions = new Map<string, { userId: string; email: string }>();

// Multer setup for file uploads
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
  }),
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf') {
      cb(null, true);
    } else {
      cb(new Error('Only PDF files are allowed'));
    }
  },
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB
});

// Middleware to check authentication
function requireAuth(req: any, res: any, next: any) {
  const sessionId = req.headers['x-session-id'] || req.cookies?.sessionId;
  const session = sessions.get(sessionId);
  
  if (!session) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  
  req.user = session;
  next();
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/signup", async (req, res) => {
    try {
      const data = insertUserSchema.parse(req.body);
      
      const existing = await storage.getUserByEmail(data.email);
      if (existing) {
        return res.status(400).json({ error: "Email already exists" });
      }

      const hashedPassword = await bcrypt.hash(data.password, 10);
      const user = await storage.createUser({
        ...data,
        password: hashedPassword
      });

      const sessionId = Math.random().toString(36).substring(7);
      sessions.set(sessionId, { userId: user.id, email: user.email });

      res.cookie('sessionId', sessionId, { httpOnly: true });
      res.json({ 
        user: { id: user.id, name: user.name, email: user.email },
        sessionId 
      });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const data = loginSchema.parse(req.body);
      
      const user = await storage.getUserByEmail(data.email);
      if (!user) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      const valid = await bcrypt.compare(data.password, user.password);
      if (!valid) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      const sessionId = Math.random().toString(36).substring(7);
      sessions.set(sessionId, { userId: user.id, email: user.email });

      res.cookie('sessionId', sessionId, { httpOnly: true });
      res.json({ 
        user: { id: user.id, name: user.name, email: user.email },
        sessionId 
      });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    const sessionId = req.headers['x-session-id'] || req.cookies?.sessionId;
    if (sessionId) {
      sessions.delete(sessionId as string);
    }
    res.clearCookie('sessionId');
    res.json({ success: true });
  });

  // Resume routes
  app.get("/api/resumes", requireAuth, async (req, res) => {
    try {
      const resumes = await storage.getUserResumes(req.user.userId);
      res.json(resumes);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/resumes/upload", requireAuth, upload.single('resume'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      // In production, this would use PyPDF2 to extract text
      // For now, we'll simulate the extraction
      const extractedText = "Sample extracted resume text with skills and experience";
      const skills = ["JavaScript", "React", "Node.js", "TypeScript", "Python"];
      const experience = ["Frontend Developer at Tech Corp", "Full Stack Engineer"];
      const education = ["BS Computer Science"];

      const resume = await storage.createResume({
        userId: req.user.userId,
        fileName: req.file.originalname,
        fileUrl: `/uploads/${req.file.filename}`,
        extractedText,
        skills,
        experience,
        education
      });

      res.json(resume);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Job Description routes
  app.post("/api/job-descriptions", requireAuth, async (req, res) => {
    try {
      const data = insertJobDescriptionSchema.parse(req.body);
      
      // Extract skills from description (in production, use NLP)
      const requiredSkills = req.body.description
        .match(/\b(JavaScript|Python|React|Node\.js|TypeScript|Java|SQL|AWS|Docker|Kubernetes)\b/gi) || [];

      const jd = await storage.createJobDescription({
        ...data,
        userId: req.user.userId,
        requiredSkills: [...new Set(requiredSkills.map((s: string) => s.toLowerCase()))]
      });

      res.json(jd);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/job-descriptions", requireAuth, async (req, res) => {
    try {
      const jds = await storage.getUserJobDescriptions(req.user.userId);
      res.json(jds);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Interview Session routes
  app.post("/api/sessions/start", requireAuth, async (req, res) => {
    try {
      const data = insertInterviewSessionSchema.parse(req.body);
      
      const session = await storage.createSession({
        ...data,
        userId: req.user.userId
      });

      res.json(session);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/sessions", requireAuth, async (req, res) => {
    try {
      const sessions = await storage.getUserSessions(req.user.userId);
      res.json(sessions);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/sessions/:id", requireAuth, async (req, res) => {
    try {
      const session = await storage.getSession(req.params.id);
      if (!session || session.userId !== req.user.userId) {
        return res.status(404).json({ error: "Session not found" });
      }
      res.json(session);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/sessions/:id/next-question", requireAuth, async (req, res) => {
    try {
      const session = await storage.getSession(req.params.id);
      if (!session || session.userId !== req.user.userId) {
        return res.status(404).json({ error: "Session not found" });
      }

      const questions = await storage.getSessionQuestions(session.id);
      const questionNumber = questions.length + 1;

      // In production, this would call Gemini API to generate a question
      // based on resume, JD, and previous answers
      const questionTexts = [
        "Tell me about a challenging project you worked on recently.",
        "How do you approach problem-solving when faced with a complex technical issue?",
        "Describe a time when you had to work with a difficult team member.",
        "What interests you about this role and our company?",
        "How do you stay updated with the latest technology trends?",
      ];

      const categories = ["behavioral", "technical", "situational"];
      
      const question = await storage.createQuestion({
        sessionId: session.id,
        questionText: questionTexts[(questionNumber - 1) % questionTexts.length],
        questionNumber,
        category: categories[questionNumber % 3]
      });

      res.json({ question });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/sessions/:id/answer", requireAuth, async (req, res) => {
    try {
      const session = await storage.getSession(req.params.id);
      if (!session || session.userId !== req.user.userId) {
        return res.status(404).json({ error: "Session not found" });
      }

      const data = insertAnswerSchema.parse(req.body);
      
      // In production, this would:
      // 1. Use Whisper for speech-to-text (if audio provided)
      // 2. Use Gemini API to evaluate the answer
      // 3. Calculate score and provide feedback
      
      const answer = await storage.createAnswer({
        ...data,
        questionId: req.body.questionId,
        sessionId: session.id
      });

      // Simulate AI evaluation
      const score = Math.floor(Math.random() * 30) + 70; // 70-100
      const strengths = ["Clear communication", "Good use of examples"];
      const improvements = ["Could provide more specific details"];

      res.json({ answer, score, strengths, improvements });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/sessions/:id/end", requireAuth, async (req, res) => {
    try {
      const session = await storage.getSession(req.params.id);
      if (!session || session.userId !== req.user.userId) {
        return res.status(404).json({ error: "Session not found" });
      }

      // Calculate scores (in production, aggregate from AI analysis)
      const overallScore = Math.floor(Math.random() * 20) + 75; // 75-95
      const verbalScore = Math.floor(Math.random() * 20) + 75;
      const nonVerbalScore = Math.floor(Math.random() * 20) + 70;
      const resumeMatchScore = Math.floor(Math.random() * 20) + 80;

      const updated = await storage.updateSession(session.id, {
        status: 'completed',
        completedAt: new Date(),
        overallScore,
        verbalScore,
        nonVerbalScore,
        resumeMatchScore
      });

      // Generate feedback
      await storage.createFeedback({
        sessionId: session.id,
        verbalFeedback: "Your verbal communication demonstrated strong clarity and professional tone throughout the interview.",
        nonVerbalFeedback: "Maintained good eye contact and posture. Consider reducing fidgeting during complex questions.",
        overallFeedback: "Strong performance overall. Continue practicing to refine your responses and build confidence.",
        recommendations: [
          "Practice the STAR method for behavioral questions",
          "Prepare specific examples from your experience",
          "Research company background before interviews"
        ],
        strengths: ["Clear articulation", "Good examples", "Confident delivery"],
        areasForImprovement: ["Reduce filler words", "More specific technical details"]
      });

      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Feedback routes
  app.get("/api/feedback/:sessionId", requireAuth, async (req, res) => {
    try {
      const session = await storage.getSession(req.params.sessionId);
      if (!session || session.userId !== req.user.userId) {
        return res.status(404).json({ error: "Session not found" });
      }

      const feedback = await storage.getSessionFeedback(req.params.sessionId);
      res.json(feedback);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Stats routes
  app.get("/api/stats", requireAuth, async (req, res) => {
    try {
      const stats = await storage.getUserStats(req.user.userId);
      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Create uploads directory if it doesn't exist
  import('fs').then(fs => {
    if (!fs.existsSync('uploads')) {
      fs.mkdirSync('uploads');
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
