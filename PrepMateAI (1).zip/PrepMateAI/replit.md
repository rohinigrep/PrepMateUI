# PrepMate - AI Mock Interview Platform

## Project Overview

PrepMate is an AI-driven mock interview platform built with React and Node.js/Express. The application helps candidates prepare for interviews through realistic practice sessions with AI-powered feedback.

## Architecture

### Frontend (React + TypeScript)
- **Framework**: React 18 with Vite
- **Styling**: Tailwind CSS + Shadcn UI components
- **State Management**: TanStack Query for server state
- **Routing**: Wouter (lightweight routing)
- **Forms**: React Hook Form + Zod validation
- **Theme**: Dark mode support with theme provider

### Backend (Node.js + Express)
- **Runtime**: Node.js 20
- **Framework**: Express with TypeScript
- **Storage**: In-memory storage (upgradeable to MongoDB)
- **Authentication**: Session-based with bcrypt password hashing
- **File Uploads**: Multer for PDF resume uploads
- **API**: RESTful endpoints for all features

### Data Models
- **Users**: Authentication and profile data
- **Resumes**: Uploaded PDFs with extracted skills/experience
- **Job Descriptions**: Target role requirements
- **Interview Sessions**: Practice session tracking
- **Questions**: AI-generated interview questions
- **Answers**: User responses with evaluation
- **Non-Verbal Analysis**: Facial expression/posture data
- **Feedback**: Comprehensive performance reports

## Key Features Implemented

### ✅ Phase 1: Schema & Frontend (Completed)
- Comprehensive data schema with Drizzle ORM and Zod validation
- Landing page with hero section, features, how-it-works, stats
- Authentication (signup/login) pages with form validation
- Dashboard with performance stats and session history
- Interview setup flow (job description + resume selection)
- Resume upload with drag-and-drop interface
- Interview session page with webcam/mic controls
- Feedback/results page with detailed analysis tabs
- Dark mode theme toggle throughout app
- Responsive design for mobile/tablet/desktop

### ✅ Phase 2: Backend (Completed)
- Complete Express API with all endpoints
- User authentication with session management
- Resume upload and parsing (PDF support)
- Job description creation with skill extraction
- Interview session management
- Question generation (simulated, ready for Gemini integration)
- Answer submission and evaluation
- Feedback generation with scores
- User statistics aggregation

### 🚧 Phase 3: Integration & AI (In Progress)
- Need to connect frontend to backend APIs
- Integrate Gemini API for intelligent Q&A
- Add Python microservice for ML capabilities:
  - Whisper for speech-to-text
  - MediaPipe for facial analysis
  - DeepFace for emotion detection
  - BERT for resume-JD matching

## Environment Variables

Required secrets (configured in Replit Secrets):
- `GEMINI_API_KEY` - Google Gemini API for question generation
- `MONGODB_URI` - MongoDB connection (optional, using in-memory by default)
- `SESSION_SECRET` - Session encryption key (optional)

## Development Workflow

1. **Start Development Server**: `npm run dev`
   - Frontend served at http://localhost:5000
   - Backend API at http://localhost:5000/api/*
   - Hot reload enabled for both

2. **Build for Production**: `npm run build`
3. **Start Production**: `npm start`

## API Integration Status

### Implemented Endpoints
- ✅ POST /api/auth/signup - User registration
- ✅ POST /api/auth/login - User login
- ✅ POST /api/auth/logout - User logout
- ✅ GET /api/resumes - List user resumes
- ✅ POST /api/resumes/upload - Upload PDF resume
- ✅ POST /api/job-descriptions - Create job description
- ✅ GET /api/job-descriptions - List job descriptions
- ✅ POST /api/sessions/start - Start interview
- ✅ GET /api/sessions - List interview sessions
- ✅ GET /api/sessions/:id - Get session details
- ✅ POST /api/sessions/:id/next-question - Generate question
- ✅ POST /api/sessions/:id/answer - Submit answer
- ✅ POST /api/sessions/:id/end - End interview
- ✅ GET /api/feedback/:sessionId - Get feedback
- ✅ GET /api/stats - User statistics

### Pending AI Integrations
- 🔄 Gemini API for dynamic question generation
- 🔄 Gemini API for answer evaluation
- 🔄 Whisper for speech-to-text
- 🔄 MediaPipe for facial landmark detection
- 🔄 DeepFace for emotion analysis
- 🔄 BERT/Sentence-Transformers for resume matching

## User Preferences

### Design System
- **Primary Color**: Confident Blue (220 90% 56%)
- **Font Family**: Inter (UI/body), Manrope (headings)
- **Component Style**: Material Design + Linear/Notion aesthetics
- **Default Theme**: Dark mode
- **Spacing**: Consistent Tailwind scale (4, 8, 12, 16, 24, 32, 48)
- **Border Radius**: Small (6px for most elements)

### Technical Decisions
- In-memory storage for development (easily switch to MongoDB)
- Session-based authentication (not JWT for simplicity)
- Simulated AI responses (ready for production AI integration)
- File uploads stored locally in /uploads directory
- No WebSocket yet (planned for real-time features)

## Next Steps

1. ✅ Complete backend implementation
2. 🔄 Connect frontend to backend (Phase 3)
3. 🔄 Integrate Gemini API for Q&A
4. 🔄 Add Python microservice for ML features
5. 🔄 Implement WebSocket for real-time interview
6. 🔄 Add comprehensive error handling
7. 🔄 Production deployment setup

## Known Limitations

- Resume parsing is simulated (needs PyPDF2 integration)
- Questions are from a static pool (needs Gemini API)
- Answer evaluation is random scores (needs Gemini API)
- No facial analysis yet (needs MediaPipe + DeepFace)
- No speech-to-text (needs Whisper)
- In-memory storage (data lost on restart)
- No WebSocket for real-time features yet

## Recent Changes

- Implemented complete data schema with all models
- Built all frontend pages with design system
- Created backend API with all endpoints
- Added authentication and session management
- Implemented resume upload functionality
- Created interview session management
- Added feedback generation system
