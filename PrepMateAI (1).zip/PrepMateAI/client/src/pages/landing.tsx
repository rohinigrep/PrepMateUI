import { Link } from "wouter";
import { Brain, Video, FileText, TrendingUp, CheckCircle, ArrowRight, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ThemeToggle } from "@/components/theme-toggle";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border bg-card/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="h-7 w-7 text-primary" />
            <span className="text-xl font-accent font-bold">PrepMate</span>
          </div>
          <div className="flex items-center gap-4">
            <ThemeToggle />
            <Link href="/login">
              <Button variant="ghost" data-testid="button-login" className="hover-elevate active-elevate-2">
                Sign In
              </Button>
            </Link>
            <Link href="/signup">
              <Button data-testid="button-signup" className="hover-elevate active-elevate-2">
                Get Started
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-16 md:pt-40 md:pb-24 px-4 md:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-5 gap-12 items-center">
            <div className="lg:col-span-3">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
                <Sparkles className="h-4 w-4 text-primary" />
                <span className="text-sm font-medium text-primary">AI-Powered Interview Preparation</span>
              </div>
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-accent font-bold leading-tight mb-6">
                Master Your
                <span className="text-primary block mt-2">Next Interview</span>
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl">
                Practice with AI-driven mock interviews that analyze your answers, body language, and resume fit. 
                Get personalized feedback to build confidence and ace your next opportunity.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link href="/signup">
                  <Button size="lg" className="text-base px-8 h-12 hover-elevate active-elevate-2" data-testid="button-hero-start">
                    Start Practicing Free
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Button size="lg" variant="outline" className="text-base px-8 h-12 hover-elevate active-elevate-2" data-testid="button-hero-demo">
                  Watch Demo
                  <Video className="ml-2 h-5 w-5" />
                </Button>
              </div>
              <div className="mt-8 flex items-center gap-8 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-chart-2" />
                  <span>No credit card required</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-chart-2" />
                  <span>Instant feedback</span>
                </div>
              </div>
            </div>
            <div className="lg:col-span-2 relative">
              <div className="relative rounded-2xl overflow-hidden border border-border shadow-2xl bg-card">
                <div className="aspect-[4/3] bg-gradient-to-br from-primary/20 to-chart-2/20 flex items-center justify-center">
                  <div className="text-center p-8">
                    <Brain className="h-24 w-24 mx-auto text-primary mb-4" />
                    <div className="space-y-2">
                      <div className="h-3 bg-foreground/10 rounded-full w-48 mx-auto"></div>
                      <div className="h-3 bg-foreground/10 rounded-full w-32 mx-auto"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 md:py-24 px-4 md:px-8 bg-card/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-accent font-semibold mb-4">
              Everything You Need to Succeed
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our AI-powered platform provides comprehensive interview preparation with real-time analysis and actionable insights.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="p-6 hover-elevate cursor-pointer transition-all" data-testid="card-feature-voice">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                <Video className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-accent font-semibold mb-2">Voice-Based Interviews</h3>
              <p className="text-muted-foreground mb-4">
                Practice with realistic voice interactions powered by advanced speech recognition and natural language processing.
              </p>
              <button className="text-primary font-medium inline-flex items-center gap-1 hover:gap-2 transition-all">
                Learn more <ArrowRight className="h-4 w-4" />
              </button>
            </Card>

            <Card className="p-6 hover-elevate cursor-pointer transition-all" data-testid="card-feature-analysis">
              <div className="w-12 h-12 rounded-lg bg-chart-2/10 flex items-center justify-center mb-4">
                <Brain className="h-6 w-6 text-chart-2" />
              </div>
              <h3 className="text-xl font-accent font-semibold mb-2">AI-Powered Analysis</h3>
              <p className="text-muted-foreground mb-4">
                Get detailed feedback on your answers, body language, facial expressions, and communication style using cutting-edge AI.
              </p>
              <button className="text-primary font-medium inline-flex items-center gap-1 hover:gap-2 transition-all">
                Learn more <ArrowRight className="h-4 w-4" />
              </button>
            </Card>

            <Card className="p-6 hover-elevate cursor-pointer transition-all" data-testid="card-feature-resume">
              <div className="w-12 h-12 rounded-lg bg-chart-3/10 flex items-center justify-center mb-4">
                <FileText className="h-6 w-6 text-chart-3" />
              </div>
              <h3 className="text-xl font-accent font-semibold mb-2">Resume-Based Questions</h3>
              <p className="text-muted-foreground mb-4">
                Upload your resume and job description to receive personalized questions tailored to your background and target role.
              </p>
              <button className="text-primary font-medium inline-flex items-center gap-1 hover:gap-2 transition-all">
                Learn more <ArrowRight className="h-4 w-4" />
              </button>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 md:py-24 px-4 md:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-accent font-semibold mb-4">
              How PrepMate Works
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Get interview-ready in four simple steps
            </p>
          </div>
          <div className="grid md:grid-cols-4 gap-8 relative">
            {[
              { icon: FileText, title: "Upload Resume", desc: "Upload your resume and target job description" },
              { icon: Video, title: "Start Interview", desc: "Begin your AI-powered mock interview session" },
              { icon: Brain, title: "AI Analysis", desc: "Get real-time analysis of your performance" },
              { icon: TrendingUp, title: "Get Feedback", desc: "Receive detailed feedback and improvement tips" },
            ].map((step, i) => (
              <div key={i} className="relative">
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center mb-4 relative z-10">
                    <step.icon className="h-8 w-8 text-primary-foreground" />
                  </div>
                  <div className="absolute top-8 left-1/2 w-full h-0.5 bg-border -z-10 hidden md:block" style={{ 
                    display: i === 3 ? 'none' : 'block' 
                  }} />
                  <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center mb-3">
                    <span className="text-sm font-bold text-primary">{i + 1}</span>
                  </div>
                  <h3 className="text-lg font-accent font-semibold mb-2">{step.title}</h3>
                  <p className="text-sm text-muted-foreground">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 md:py-24 px-4 md:px-8 bg-card/30">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { value: "10K+", label: "Active Users" },
              { value: "50K+", label: "Sessions Completed" },
              { value: "85%", label: "Success Rate" },
              { value: "500+", label: "Partner Companies" },
            ].map((stat, i) => (
              <div key={i} className="text-center">
                <div className="text-4xl md:text-5xl font-accent font-bold text-primary mb-2">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 px-4 md:px-8">
        <div className="max-w-4xl mx-auto">
          <Card className="p-12 text-center bg-primary/10 border-primary/20">
            <h2 className="text-3xl md:text-4xl font-accent font-bold mb-4">
              Ready to Ace Your Next Interview?
            </h2>
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              Join thousands of candidates who have improved their interview skills with PrepMate's AI-powered platform.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link href="/signup">
                <Button size="lg" className="text-base px-8 h-12 hover-elevate active-elevate-2" data-testid="button-cta-signup">
                  Get Started Free
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4 md:px-8">
        <div className="max-w-7xl mx-auto text-center text-sm text-muted-foreground">
          <p>© 2025 PrepMate. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
