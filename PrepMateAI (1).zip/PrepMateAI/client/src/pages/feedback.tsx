import { useParams, Link } from "wouter";
import { Brain, ArrowLeft, TrendingUp, MessageSquare, Eye, FileText, Download, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { useQuery } from "@tanstack/react-query";
import { ThemeToggle } from "@/components/theme-toggle";
import { Skeleton } from "@/components/ui/skeleton";

export default function Feedback() {
  const params = useParams();
  const sessionId = params.id;

  const { data: session, isLoading } = useQuery<any>({
    queryKey: ["/api/sessions", sessionId],
  });

  const { data: feedback, isLoading: feedbackLoading } = useQuery<any>({
    queryKey: ["/api/feedback", sessionId],
  });

  if (isLoading || feedbackLoading) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b border-border bg-card/80 backdrop-blur-md sticky top-0 z-40">
          <div className="max-w-7xl mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Brain className="h-7 w-7 text-primary" />
              <span className="text-xl font-accent font-bold">PrepMate</span>
            </div>
            <ThemeToggle />
          </div>
        </header>
        <main className="max-w-7xl mx-auto px-4 md:px-8 py-8">
          <div className="space-y-6">
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-64 w-full" />
          </div>
        </main>
      </div>
    );
  }

  const overallScore = session?.overallScore || 0;
  const verbalScore = session?.verbalScore || 0;
  const nonVerbalScore = session?.nonVerbalScore || 0;
  const resumeMatchScore = session?.resumeMatchScore || 0;

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card/80 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="h-7 w-7 text-primary" />
            <span className="text-xl font-accent font-bold">PrepMate</span>
          </div>
          <ThemeToggle />
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 md:px-8 py-8">
        <Link href="/dashboard">
          <Button variant="ghost" className="mb-6 hover-elevate active-elevate-2" data-testid="button-back">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </Link>

        {/* Header Card */}
        <Card className="p-8 mb-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -z-10" />
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="relative">
              <svg className="w-32 h-32 transform -rotate-90">
                <circle
                  cx="64"
                  cy="64"
                  r="56"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="none"
                  className="text-secondary"
                />
                <circle
                  cx="64"
                  cy="64"
                  r="56"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="none"
                  strokeDasharray={`${(overallScore / 100) * 351.86} 351.86`}
                  className="text-primary transition-all duration-1000"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-3xl font-accent font-bold">{overallScore}</div>
                  <div className="text-xs text-muted-foreground">Score</div>
                </div>
              </div>
            </div>
            <div className="flex-1 text-center md:text-left">
              <h1 className="text-3xl md:text-4xl font-accent font-bold mb-2">
                {overallScore >= 80 ? "Excellent Performance!" : overallScore >= 60 ? "Good Job!" : "Keep Practicing!"}
              </h1>
              <p className="text-muted-foreground mb-4">
                Interview completed on {new Date(session?.completedAt || Date.now()).toLocaleDateString()}
              </p>
              <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                <Badge variant="secondary">
                  {session?.jobTitle || "Interview Session"}
                </Badge>
                <Badge variant="secondary" className="capitalize">
                  {session?.difficultyLevel}
                </Badge>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="hover-elevate active-elevate-2" data-testid="button-download">
                <Download className="h-4 w-4 mr-2" />
                Download Report
              </Button>
              <Link href="/dashboard">
                <Button className="hover-elevate active-elevate-2" data-testid="button-dashboard">
                  <Home className="h-4 w-4 mr-2" />
                  Dashboard
                </Button>
              </Link>
            </div>
          </div>
        </Card>

        {/* Performance Metrics */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <MessageSquare className="h-5 w-5 text-primary" />
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Verbal Communication</div>
                <div className="text-2xl font-accent font-bold">{verbalScore}%</div>
              </div>
            </div>
            <Progress value={verbalScore} className="h-2" />
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-chart-2/10 flex items-center justify-center">
                <Eye className="h-5 w-5 text-chart-2" />
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Non-Verbal Cues</div>
                <div className="text-2xl font-accent font-bold">{nonVerbalScore}%</div>
              </div>
            </div>
            <Progress value={nonVerbalScore} className="h-2" />
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-chart-3/10 flex items-center justify-center">
                <FileText className="h-5 w-5 text-chart-3" />
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Resume Match</div>
                <div className="text-2xl font-accent font-bold">{resumeMatchScore}%</div>
              </div>
            </div>
            <Progress value={resumeMatchScore} className="h-2" />
          </Card>
        </div>

        {/* Detailed Feedback */}
        <Tabs defaultValue="verbal" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="verbal" data-testid="tab-verbal">Verbal Analysis</TabsTrigger>
            <TabsTrigger value="nonverbal" data-testid="tab-nonverbal">Non-Verbal Analysis</TabsTrigger>
            <TabsTrigger value="resume" data-testid="tab-resume">Resume Match</TabsTrigger>
            <TabsTrigger value="recommendations" data-testid="tab-recommendations">Recommendations</TabsTrigger>
          </TabsList>

          <TabsContent value="verbal" className="space-y-4">
            <Card className="p-6">
              <h3 className="text-xl font-accent font-semibold mb-4">Verbal Communication Analysis</h3>
              <p className="text-muted-foreground mb-6">
                {feedback?.verbalFeedback || "Your verbal communication showed good clarity and structure. You maintained a professional tone throughout the interview."}
              </p>
              
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="strengths">
                  <AccordionTrigger className="hover-elevate">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-chart-2" />
                      <span>Strengths</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <ul className="space-y-2 ml-6">
                      {(feedback?.strengths || ["Clear articulation", "Good use of examples", "Confident delivery"]).map((strength: string, i: number) => (
                        <li key={i} className="text-muted-foreground list-disc">{strength}</li>
                      ))}
                    </ul>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="improvements">
                  <AccordionTrigger className="hover-elevate">
                    <div className="flex items-center gap-2">
                      <MessageSquare className="h-4 w-4 text-chart-3" />
                      <span>Areas for Improvement</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <ul className="space-y-2 ml-6">
                      {(feedback?.areasForImprovement || ["Reduce filler words", "Provide more specific examples", "Structure answers using STAR method"]).map((improvement: string, i: number) => (
                        <li key={i} className="text-muted-foreground list-disc">{improvement}</li>
                      ))}
                    </ul>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </Card>
          </TabsContent>

          <TabsContent value="nonverbal" className="space-y-4">
            <Card className="p-6">
              <h3 className="text-xl font-accent font-semibold mb-4">Non-Verbal Communication Analysis</h3>
              <p className="text-muted-foreground mb-6">
                {feedback?.nonVerbalFeedback || "Your body language and facial expressions demonstrated engagement and confidence during the interview."}
              </p>

              <div className="grid md:grid-cols-2 gap-4 mb-6">
                <div className="p-4 rounded-lg bg-card border border-border">
                  <div className="text-sm text-muted-foreground mb-1">Eye Contact</div>
                  <div className="text-2xl font-accent font-semibold">Good</div>
                </div>
                <div className="p-4 rounded-lg bg-card border border-border">
                  <div className="text-sm text-muted-foreground mb-1">Posture</div>
                  <div className="text-2xl font-accent font-semibold">Excellent</div>
                </div>
                <div className="p-4 rounded-lg bg-card border border-border">
                  <div className="text-sm text-muted-foreground mb-1">Facial Expression</div>
                  <div className="text-2xl font-accent font-semibold">Confident</div>
                </div>
                <div className="p-4 rounded-lg bg-card border border-border">
                  <div className="text-sm text-muted-foreground mb-1">Engagement Level</div>
                  <div className="text-2xl font-accent font-semibold">High</div>
                </div>
              </div>

              <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                <h4 className="font-semibold mb-2">Key Observations</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>✓ Maintained consistent eye contact throughout</li>
                  <li>✓ Demonstrated engaged and attentive facial expressions</li>
                  <li>✓ Posture was professional and confident</li>
                  <li>⚠ Occasional fidgeting noticed during complex questions</li>
                </ul>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="resume" className="space-y-4">
            <Card className="p-6">
              <h3 className="text-xl font-accent font-semibold mb-4">Resume Match Analysis</h3>
              <p className="text-muted-foreground mb-6">
                Your answers aligned well with your resume and the job requirements. Here's how your responses matched the expected qualifications.
              </p>

              <div className="space-y-4">
                <div className="p-4 rounded-lg border border-border">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">Technical Skills Match</span>
                    <span className="text-sm font-semibold">{Math.floor(resumeMatchScore * 0.9)}%</span>
                  </div>
                  <Progress value={resumeMatchScore * 0.9} className="h-2" />
                </div>

                <div className="p-4 rounded-lg border border-border">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">Experience Relevance</span>
                    <span className="text-sm font-semibold">{Math.floor(resumeMatchScore * 1.1)}%</span>
                  </div>
                  <Progress value={resumeMatchScore * 1.1} className="h-2" />
                </div>

                <div className="p-4 rounded-lg border border-border">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">Role Alignment</span>
                    <span className="text-sm font-semibold">{resumeMatchScore}%</span>
                  </div>
                  <Progress value={resumeMatchScore} className="h-2" />
                </div>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="recommendations" className="space-y-4">
            <Card className="p-6">
              <h3 className="text-xl font-accent font-semibold mb-4">Personalized Recommendations</h3>
              <div className="space-y-6">
                {(feedback?.recommendations || [
                  "Practice the STAR method for behavioral questions to provide more structured responses",
                  "Work on reducing filler words (um, uh, like) by recording yourself and listening back",
                  "Research the company's recent projects and incorporate them into your answers",
                  "Prepare 3-4 stories that demonstrate key competencies for the role",
                ]).map((recommendation: string, i: number) => (
                  <div key={i} className="flex gap-4 p-4 rounded-lg bg-card border border-border hover-elevate transition-all">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-bold text-primary">{i + 1}</span>
                    </div>
                    <div>
                      <p className="text-muted-foreground">{recommendation}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-6 bg-primary/5 border-primary/20">
              <h3 className="font-accent font-semibold mb-3">Next Steps</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Keep practicing to improve your interview skills. Consider scheduling another session to track your progress.
              </p>
              <Link href="/setup">
                <Button className="hover-elevate active-elevate-2" data-testid="button-practice-again">
                  Practice Again
                </Button>
              </Link>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
