import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Brain, ArrowLeft, FileText, Briefcase, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertInterviewSessionSchema, insertJobDescriptionSchema, type InsertInterviewSession, type InsertJobDescription } from "@shared/schema";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { ThemeToggle } from "@/components/theme-toggle";

export default function Setup() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [step, setStep] = useState(1);

  const { data: resumes } = useQuery<any[]>({
    queryKey: ["/api/resumes"],
  });

  const jdForm = useForm<InsertJobDescription>({
    resolver: zodResolver(insertJobDescriptionSchema),
    defaultValues: {
      title: "",
      description: "",
      requiredSkills: [],
      difficultyLevel: "intermediate",
    },
  });

  const sessionForm = useForm<any>({
    defaultValues: {
      resumeId: "",
      jobDescriptionId: "",
      difficultyLevel: "intermediate",
    },
  });

  const createJdMutation = useMutation({
    mutationFn: (data: InsertJobDescription) => apiRequest("POST", "/api/job-descriptions", data),
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/job-descriptions"] });
      sessionForm.setValue("jobDescriptionId", data.id);
      setStep(2);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create job description.",
        variant: "destructive",
      });
    },
  });

  const startSessionMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/sessions/start", data),
    onSuccess: (data: any) => {
      toast({
        title: "Interview starting!",
        description: "Get ready for your practice session.",
      });
      setLocation(`/interview/${data.id}`);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to start interview.",
        variant: "destructive",
      });
    },
  });

  const onSubmitJd = (data: InsertJobDescription) => {
    createJdMutation.mutate(data);
  };

  const onStartInterview = (data: any) => {
    if (!data.resumeId) {
      toast({
        title: "Resume required",
        description: "Please select a resume to continue.",
        variant: "destructive",
      });
      return;
    }
    startSessionMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card/80 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="h-7 w-7 text-primary" />
            <span className="text-xl font-accent font-bold">PrepMate</span>
          </div>
          <ThemeToggle />
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 md:px-8 py-8">
        <Link href="/dashboard">
          <Button variant="ghost" className="mb-6 hover-elevate active-elevate-2" data-testid="button-back">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </Link>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-center gap-4 mb-8">
            <div className={`flex items-center gap-2 ${step >= 1 ? 'text-primary' : 'text-muted-foreground'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-primary text-primary-foreground' : 'bg-secondary'}`}>
                1
              </div>
              <span className="font-medium hidden sm:inline">Job Details</span>
            </div>
            <div className="w-16 h-0.5 bg-border"></div>
            <div className={`flex items-center gap-2 ${step >= 2 ? 'text-primary' : 'text-muted-foreground'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-primary text-primary-foreground' : 'bg-secondary'}`}>
                2
              </div>
              <span className="font-medium hidden sm:inline">Select Resume</span>
            </div>
          </div>
        </div>

        {step === 1 && (
          <Card className="p-8">
            <div className="mb-6">
              <h1 className="text-3xl font-accent font-bold mb-2">Job Description</h1>
              <p className="text-muted-foreground">Tell us about the role you're preparing for</p>
            </div>

            <form onSubmit={jdForm.handleSubmit(onSubmitJd)} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="title">Job Title</Label>
                <Input
                  id="title"
                  placeholder="e.g., Frontend Engineer"
                  data-testid="input-job-title"
                  className="h-12"
                  {...jdForm.register("title")}
                />
                {jdForm.formState.errors.title && (
                  <p className="text-sm text-destructive">{jdForm.formState.errors.title.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Job Description</Label>
                <Textarea
                  id="description"
                  placeholder="Paste the job description here..."
                  data-testid="input-job-description"
                  className="min-h-32"
                  {...jdForm.register("description")}
                />
                {jdForm.formState.errors.description && (
                  <p className="text-sm text-destructive">{jdForm.formState.errors.description.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="difficulty">Difficulty Level</Label>
                <Select 
                  onValueChange={(value) => jdForm.setValue("difficultyLevel", value as any)}
                  defaultValue="intermediate"
                >
                  <SelectTrigger className="h-12" data-testid="select-difficulty">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="beginner">Beginner</SelectItem>
                    <SelectItem value="intermediate">Intermediate</SelectItem>
                    <SelectItem value="advanced">Advanced</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button 
                type="submit" 
                className="w-full h-12 hover-elevate active-elevate-2"
                disabled={createJdMutation.isPending}
                data-testid="button-continue"
              >
                {createJdMutation.isPending ? "Processing..." : "Continue"}
              </Button>
            </form>
          </Card>
        )}

        {step === 2 && (
          <Card className="p-8">
            <div className="mb-6">
              <h1 className="text-3xl font-accent font-bold mb-2">Select Resume</h1>
              <p className="text-muted-foreground">Choose a resume for personalized questions</p>
            </div>

            <form onSubmit={sessionForm.handleSubmit(onStartInterview)} className="space-y-6">
              {resumes && resumes.length > 0 ? (
                <div className="space-y-3">
                  {resumes.map((resume: any) => (
                    <div
                      key={resume.id}
                      onClick={() => sessionForm.setValue("resumeId", resume.id)}
                      className={`p-4 border-2 rounded-lg cursor-pointer transition-all hover-elevate ${
                        sessionForm.watch("resumeId") === resume.id
                          ? "border-primary bg-primary/5"
                          : "border-border"
                      }`}
                      data-testid={`resume-${resume.id}`}
                    >
                      <div className="flex items-center gap-3">
                        <FileText className="h-5 w-5 text-primary" />
                        <div className="flex-1">
                          <div className="font-medium">{resume.fileName}</div>
                          <div className="text-sm text-muted-foreground">
                            Uploaded {new Date(resume.uploadedAt).toLocaleDateString()}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground mb-4">No resumes uploaded yet</p>
                  <Link href="/resume">
                    <Button variant="outline" data-testid="button-upload-resume">
                      Upload Resume
                    </Button>
                  </Link>
                </div>
              )}

              <div className="flex gap-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setStep(1)}
                  className="flex-1 h-12 hover-elevate active-elevate-2"
                  data-testid="button-back-step"
                >
                  Back
                </Button>
                <Button 
                  type="submit" 
                  className="flex-1 h-12 hover-elevate active-elevate-2"
                  disabled={startSessionMutation.isPending || !sessionForm.watch("resumeId")}
                  data-testid="button-start-interview"
                >
                  {startSessionMutation.isPending ? "Starting..." : (
                    <>
                      <Play className="h-5 w-5 mr-2" />
                      Start Interview
                    </>
                  )}
                </Button>
              </div>
            </form>
          </Card>
        )}
      </main>
    </div>
  );
}
