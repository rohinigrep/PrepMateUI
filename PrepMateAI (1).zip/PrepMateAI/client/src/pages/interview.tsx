import { useState, useEffect, useRef } from "react";
import { useParams, useLocation } from "wouter";
import { Brain, Mic, MicOff, Video as VideoIcon, VideoOff, StopCircle, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Interview() {
  const params = useParams();
  const sessionId = params.id;
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [micEnabled, setMicEnabled] = useState(true);
  const [cameraEnabled, setCameraEnabled] = useState(true);
  const [isRecording, setIsRecording] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState<any>(null);
  const [questionNumber, setQuestionNumber] = useState(1);
  const [timeLeft, setTimeLeft] = useState(120);

  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);

  const { data: session, isLoading } = useQuery<any>({
    queryKey: ["/api/sessions", sessionId],
  });

  const nextQuestionMutation = useMutation({
    mutationFn: () => apiRequest("POST", `/api/sessions/${sessionId}/next-question`, {}),
    onSuccess: (data: any) => {
      setCurrentQuestion(data.question);
      setQuestionNumber(prev => prev + 1);
      setTimeLeft(120);
      setIsRecording(false);
    },
  });

  const submitAnswerMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", `/api/sessions/${sessionId}/answer`, data),
    onSuccess: () => {
      nextQuestionMutation.mutate();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit answer.",
        variant: "destructive",
      });
    },
  });

  const endSessionMutation = useMutation({
    mutationFn: () => apiRequest("POST", `/api/sessions/${sessionId}/end`, {}),
    onSuccess: () => {
      toast({
        title: "Interview completed!",
        description: "Analyzing your performance...",
      });
      setLocation(`/feedback/${sessionId}`);
    },
  });

  useEffect(() => {
    const initCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: true,
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (err) {
        toast({
          title: "Camera access denied",
          description: "Please enable camera and microphone permissions.",
          variant: "destructive",
        });
      }
    };

    initCamera();

    return () => {
      if (videoRef.current?.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
        tracks.forEach(track => track.stop());
      }
    };
  }, [toast]);

  useEffect(() => {
    if (!currentQuestion) {
      nextQuestionMutation.mutate();
    }
  }, []);

  useEffect(() => {
    if (timeLeft > 0 && isRecording) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && isRecording) {
      handleStopRecording();
    }
  }, [timeLeft, isRecording]);

  const toggleMic = () => {
    setMicEnabled(!micEnabled);
    if (videoRef.current?.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getAudioTracks();
      tracks.forEach(track => track.enabled = !micEnabled);
    }
  };

  const toggleCamera = () => {
    setCameraEnabled(!cameraEnabled);
    if (videoRef.current?.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getVideoTracks();
      tracks.forEach(track => track.enabled = !cameraEnabled);
    }
  };

  const handleStartRecording = () => {
    setIsRecording(true);
    setTimeLeft(120);
  };

  const handleStopRecording = () => {
    setIsRecording(false);
    submitAnswerMutation.mutate({
      questionId: currentQuestion?.id,
      transcribedText: "Sample answer text",
    });
  };

  const handleEndInterview = () => {
    if (window.confirm("Are you sure you want to end the interview?")) {
      endSessionMutation.mutate();
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Brain className="h-12 w-12 mx-auto text-primary mb-4 animate-pulse" />
          <p className="text-muted-foreground">Loading interview...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur-md px-4 md:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Brain className="h-7 w-7 text-primary" />
          <div>
            <div className="font-accent font-semibold">{session?.jobTitle || "Interview Session"}</div>
            <div className="text-xs text-muted-foreground">
              Question {questionNumber} • {Math.floor(timeLeft / 60)}:{String(timeLeft % 60).padStart(2, '0')}
            </div>
          </div>
        </div>
        <Badge variant="secondary" className="font-semibold capitalize">
          {session?.difficultyLevel}
        </Badge>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center p-4 md:p-8">
        <div className="w-full max-w-4xl">
          {/* Question Card */}
          <Card className="p-8 mb-6 relative overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-1 bg-secondary">
              <div 
                className="h-full bg-primary transition-all duration-1000"
                style={{ width: `${(timeLeft / 120) * 100}%` }}
              />
            </div>
            
            {currentQuestion ? (
              <div className="text-center py-8">
                <Badge variant="outline" className="mb-4">
                  {currentQuestion.category}
                </Badge>
                <h2 className="text-2xl md:text-3xl font-accent font-semibold mb-6">
                  {currentQuestion.questionText}
                </h2>
                {isRecording && (
                  <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-destructive/10 border border-destructive/20">
                    <div className="w-2 h-2 rounded-full bg-destructive animate-pulse" />
                    <span className="text-sm font-medium text-destructive">Recording...</span>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-8">
                <Brain className="h-12 w-12 mx-auto text-primary mb-4 animate-pulse" />
                <p className="text-muted-foreground">Generating next question...</p>
              </div>
            )}
          </Card>

          {/* Video Feed */}
          <div className="fixed bottom-24 right-8 w-64 h-48 rounded-lg overflow-hidden border-2 border-border shadow-xl z-30 bg-black">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover"
              style={{ display: cameraEnabled ? 'block' : 'none' }}
            />
            {!cameraEnabled && (
              <div className="w-full h-full flex items-center justify-center bg-card">
                <VideoOff className="h-12 w-12 text-muted-foreground" />
              </div>
            )}
            <div className="absolute top-2 left-2 flex gap-1">
              <Badge variant="secondary" className="text-xs">
                Live
              </Badge>
              <Badge variant={isRecording ? "destructive" : "secondary"} className="text-xs">
                {isRecording ? "Recording" : "Ready"}
              </Badge>
            </div>
          </div>
        </div>
      </main>

      {/* Control Panel */}
      <div className="fixed bottom-0 left-0 right-0 h-20 border-t border-border bg-card/95 backdrop-blur-md px-4 md:px-8 flex items-center justify-center gap-4 z-40">
        <Button
          size="icon"
          variant={micEnabled ? "default" : "destructive"}
          className="h-12 w-12 rounded-full hover-elevate active-elevate-2"
          onClick={toggleMic}
          data-testid="button-toggle-mic"
        >
          {micEnabled ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
        </Button>

        <Button
          size="icon"
          variant={cameraEnabled ? "default" : "destructive"}
          className="h-12 w-12 rounded-full hover-elevate active-elevate-2"
          onClick={toggleCamera}
          data-testid="button-toggle-camera"
        >
          {cameraEnabled ? <VideoIcon className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
        </Button>

        {!isRecording ? (
          <Button
            size="lg"
            onClick={handleStartRecording}
            className="h-12 px-8 hover-elevate active-elevate-2"
            data-testid="button-start-recording"
          >
            Start Answer
          </Button>
        ) : (
          <Button
            size="lg"
            onClick={handleStopRecording}
            disabled={submitAnswerMutation.isPending}
            className="h-12 px-8 hover-elevate active-elevate-2"
            data-testid="button-stop-recording"
          >
            {submitAnswerMutation.isPending ? "Submitting..." : "Submit Answer"}
          </Button>
        )}

        <Button
          size="icon"
          variant="destructive"
          className="h-12 w-12 rounded-full hover-elevate active-elevate-2"
          onClick={handleEndInterview}
          data-testid="button-end-interview"
        >
          <StopCircle className="h-5 w-5" />
        </Button>
      </div>
    </div>
  );
}
