import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Brain, Video, TrendingUp, FileText, Plus, Clock, BarChart3, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ThemeToggle } from "@/components/theme-toggle";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/lib/auth-context";

export default function Dashboard() {
  const { logout } = useAuth();
  const { data: sessions, isLoading } = useQuery<any[]>({
    queryKey: ["/api/sessions"],
  });

  const { data: stats } = useQuery<any>({
    queryKey: ["/api/stats"],
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="h-7 w-7 text-primary" />
            <span className="text-xl font-accent font-bold">PrepMate</span>
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button 
              variant="ghost" 
              size="icon" 
              className="hover-elevate active-elevate-2" 
              onClick={logout}
              data-testid="button-logout"
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 md:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-accent font-bold mb-2">Welcome back!</h1>
          <p className="text-muted-foreground">Ready to practice for your next interview?</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Video className="h-5 w-5 text-primary" />
              </div>
              <TrendingUp className="h-4 w-4 text-chart-2" />
            </div>
            <div className="text-2xl font-accent font-bold mb-1">{stats?.totalSessions || 0}</div>
            <div className="text-sm text-muted-foreground">Total Sessions</div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-10 h-10 rounded-lg bg-chart-2/10 flex items-center justify-center">
                <BarChart3 className="h-5 w-5 text-chart-2" />
              </div>
              <TrendingUp className="h-4 w-4 text-chart-2" />
            </div>
            <div className="text-2xl font-accent font-bold mb-1">{stats?.avgScore || 0}%</div>
            <div className="text-sm text-muted-foreground">Average Score</div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-10 h-10 rounded-lg bg-chart-3/10 flex items-center justify-center">
                <FileText className="h-5 w-5 text-chart-3" />
              </div>
            </div>
            <div className="text-2xl font-accent font-bold mb-1">{stats?.resumesUploaded || 0}</div>
            <div className="text-sm text-muted-foreground">Resumes Uploaded</div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-10 h-10 rounded-lg bg-chart-1/10 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-chart-1" />
              </div>
              <TrendingUp className="h-4 w-4 text-chart-2" />
            </div>
            <div className="text-2xl font-accent font-bold mb-1">+{stats?.improvement || 0}%</div>
            <div className="text-sm text-muted-foreground">Improvement</div>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Quick Actions */}
            <Card className="p-6">
              <h2 className="text-xl font-accent font-semibold mb-4">Quick Actions</h2>
              <div className="grid md:grid-cols-2 gap-4">
                <Link href="/setup">
                  <Button className="w-full h-auto py-6 flex-col gap-2 hover-elevate active-elevate-2" data-testid="button-new-interview">
                    <Plus className="h-6 w-6" />
                    <div>
                      <div className="font-semibold">New Interview</div>
                      <div className="text-xs text-primary-foreground/80">Start a new practice session</div>
                    </div>
                  </Button>
                </Link>
                <Link href="/resume">
                  <Button variant="outline" className="w-full h-auto py-6 flex-col gap-2 hover-elevate active-elevate-2" data-testid="button-upload-resume">
                    <FileText className="h-6 w-6" />
                    <div>
                      <div className="font-semibold">Upload Resume</div>
                      <div className="text-xs text-muted-foreground">Update your profile</div>
                    </div>
                  </Button>
                </Link>
              </div>
            </Card>

            {/* Recent Sessions */}
            <Card className="p-6">
              <h2 className="text-xl font-accent font-semibold mb-4">Recent Sessions</h2>
              {isLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center gap-4">
                      <Skeleton className="w-12 h-12 rounded-lg" />
                      <div className="flex-1 space-y-2">
                        <Skeleton className="h-4 w-48" />
                        <Skeleton className="h-3 w-32" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : sessions && sessions.length > 0 ? (
                <div className="space-y-4">
                  {sessions.slice(0, 5).map((session: any) => (
                    <Link key={session.id} href={`/feedback/${session.id}`}>
                      <div className="flex items-center gap-4 p-4 rounded-lg hover-elevate cursor-pointer transition-all border border-transparent hover:border-border" data-testid={`session-${session.id}`}>
                        <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <Video className="h-6 w-6 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-medium mb-1">{session.jobTitle || "Interview Session"}</div>
                          <div className="text-sm text-muted-foreground flex items-center gap-2">
                            <Clock className="h-3 w-3" />
                            {new Date(session.startedAt).toLocaleDateString()}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {session.overallScore && (
                            <Badge variant="secondary" className="font-semibold">
                              {session.overallScore}%
                            </Badge>
                          )}
                          <Badge 
                            variant={session.status === 'completed' ? 'default' : 'secondary'}
                            className="capitalize"
                          >
                            {session.status}
                          </Badge>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Video className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground mb-4">No sessions yet</p>
                  <Link href="/setup">
                    <Button data-testid="button-first-interview">Start Your First Interview</Button>
                  </Link>
                </div>
              )}
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Performance Overview */}
            <Card className="p-6">
              <h3 className="font-accent font-semibold mb-4">Performance Overview</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">Verbal Communication</span>
                    <span className="text-sm font-medium">{stats?.verbalScore || 0}%</span>
                  </div>
                  <div className="h-2 bg-secondary rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-primary rounded-full transition-all"
                      style={{ width: `${stats?.verbalScore || 0}%` }}
                    />
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">Non-Verbal Cues</span>
                    <span className="text-sm font-medium">{stats?.nonVerbalScore || 0}%</span>
                  </div>
                  <div className="h-2 bg-secondary rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-chart-2 rounded-full transition-all"
                      style={{ width: `${stats?.nonVerbalScore || 0}%` }}
                    />
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">Resume Match</span>
                    <span className="text-sm font-medium">{stats?.resumeMatchScore || 0}%</span>
                  </div>
                  <div className="h-2 bg-secondary rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-chart-3 rounded-full transition-all"
                      style={{ width: `${stats?.resumeMatchScore || 0}%` }}
                    />
                  </div>
                </div>
              </div>
            </Card>

            {/* Tips */}
            <Card className="p-6 bg-primary/5 border-primary/20">
              <h3 className="font-accent font-semibold mb-3">💡 Today's Tip</h3>
              <p className="text-sm text-muted-foreground">
                Practice maintaining eye contact with the camera during your interview. 
                This helps build confidence and creates a strong impression.
              </p>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
